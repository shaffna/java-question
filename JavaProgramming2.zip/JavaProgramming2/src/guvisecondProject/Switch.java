package guvisecondProject;

import java.util.Scanner;

public class Switch {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        System.out.print("Enter month number: ");
        int month = scanner.nextInt();
        System.out.print("Enter room rent per day: ");
        double rentPerDay = scanner.nextDouble();
        System.out.print("Enter number of days stayed: ");
        int daysStayed = scanner.nextInt();

        double totalTariff = rentPerDay * daysStayed;
        switch (month) {
            case 4:
            case 5:
            case 6:
            case 11:
            case 12:
                totalTariff *= 1.2;
                break;
            default:
                break;
        }

        System.out.printf("Total tariff: %.2f%n", totalTariff);
        scanner.close();
	}

}
